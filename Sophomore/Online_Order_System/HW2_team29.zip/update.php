<?php
    $dbservername='localhost';
    $dbname='hw2';
    $dbusername='root';
    $dbpassword='Ab1824018)';

    try{
        $conn = new PDO("mysql:host=$dbservername;dbname=$dbname", 
        $dbusername, $dbpassword);
        # set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $json = file_get_contents('myfile.json');
        $json_data = json_decode($json,true);
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $name = $_POST['mealname'];
        $sid = $json_data['SID'];

        if(empty($price))
            throw new Exception('price欄位空白');

        if(empty($quantity))
            throw new Exception('quantity欄位空白');

        if(!ctype_digit($quantity) || !ctype_digit($price))
            throw new Exception('價錢及數量為自然數');

        if(intval($quantity) < 0 || intval($price) < 0)
            throw new Exception('價錢及數量為自然數');

        if(explode($quantity,'0')[0] == null || explode($price,'0')[0] == null)
            throw new Exception('價錢及數量為自然數');
        
        $sql = "update 商品 set 價格 = $price, 庫存 = $quantity 
        where 商品.商品名稱 = '$name' and 商品.SID = '$sid';";   
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $sql = "select * from 店名 NATURAL JOIN 商品 where SID =$sid";
        $stmt_3 = $conn->prepare($sql);
        $stmt_3->execute();
        $row_2 = $stmt_3->fetchALL();  
        if($stmt_3->rowCount()>0)
        {
            $SID = $row_2[0][0];
            $i = 0;
            $array_2 = array();
            while($i<$stmt_3->rowCount())
            {
                array_push($array_2, array('shopname' => $row_2[$i]['店名'], 'category' => $row_2[$i]['類別'],'price'=>$row_2[$i]['價格'],'product_name'=>$row_2[$i]['商品名稱'], 'number' =>$row_2[$i]['庫存'], 'picture' =>$row_2[$i]['圖片'] ,'picture_type'=>$row_2[$i]['圖片型態']));
                $i = $i+1;
            }
            $json_2 = json_encode($array_2);
            $bytes_2 = file_put_contents("shop.json",$json_2);
            header("Location: https://localhost/HW2_front_end_template/HW2_front_end_template/nav.html");
            exit();
        }
    }
        
    catch(Exception $e)
    {
        $msg=$e->getMessage();
        session_unset(); 
        session_destroy(); 
        echo <<<EOT
        <!DOCTYPE html>
        <html>
        <body>
        <script>
        alert("$msg");
        window.location.replace("nav.html");
        </script>
        </body>
        </html>
    EOT;
    }

?>