<?php
    $Json = file_get_contents("myfile.json");
    $myarray = json_decode($Json, true);
    $array = Array(
        'username'=>$myarray['username'],
        'name'=>$myarray['name'],
        'phonenumber'=>$myarray['phonenumber'],
        'latitude'=>$myarray['latitude'],
        'longitude'=>$myarray['longitude'],
        'money'=>$_POST['value']+$myarray['money']
    );
    $json = json_encode($array);
    $bytes = file_put_contents("myfile.json", $json);
    header("Location: https://localhost/HW2_front_end_template/HW2_front_end_template/nav.html");
    exit();
?>