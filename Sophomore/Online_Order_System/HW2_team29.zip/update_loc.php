<?php
    $servername = 'localhost';
	$dbusername = "root";
	$dbpassword = "Ab1824018)";
	$db="hw2";
try
{   
    $Json = file_get_contents("myfile.json");
    $myarray = json_decode($Json, true);
    $array = Array(
        'username'=>$myarray['username'],
        'name'=>$myarray['name'],
        'phonenumber'=>$myarray['phonenumber'],
        'latitude'=>$_POST['latitude'],
        'longitude'=>$_POST['longitude'],
        'money'=>$myarray['money']
    );
    $json = json_encode($array);
    $bytes = file_put_contents("myfile.json", $json);
    $conn = mysqli_connect($servername, $dbusername, $dbpassword, $db) 
    or die("ERROR: Could not connect. " . mysqli_connect_error());
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    if(empty($latitude) || empty($longitude))   throw new Exception('欄位空白');
    if(!is_numeric($latitude) || !is_numeric($longitude)) 
        throw new Exception('經緯度為數字');
    if(floatval($latitude) < -90 || floatval($latitude) > 90) 
        throw new Exception('緯度格式錯誤');

    if(floatval($longitude) < -180 || floatval($longitude) > 180) 
        throw new Exception('經度格式錯誤');
    $real = hash('sha256',$myarray['username']);
    $sql = "update 使用者 set  經度=". $longitude.", 緯度=" . $latitude ." where username='" .$real. "'";
    if(mysqli_query($conn, $sql)){
        mysqli_close($conn);
        header("Location: https://localhost/HW2_front_end_template/HW2_front_end_template/nav.html");
        exit();
    }
    else{
        mysqli_close($conn);
        header("Location: https://localhost/HW2_front_end_template/HW2_front_end_template/nav.html");
        exit();
    }
}
catch(Exception $e)
{
    $msg=$e->getMessage();
    session_unset(); 
    session_destroy(); 
    echo <<<EOT
    <!DOCTYPE html>
    <html>
    <body>
    <script>
    alert("$msg");
    window.location.replace("nav.html");
    </script>
    </body>
    </html>
    EOT;
}
?>
