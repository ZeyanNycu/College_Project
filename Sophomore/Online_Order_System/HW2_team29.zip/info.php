<?php
    echo '123';
    echo "Account: ".$_Session['name'].','.$_SEssion['username'];
?>