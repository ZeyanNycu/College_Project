<?php
    $dbservername = 'localhost';
	$dbusername = "root";
	$dbpassword = "Ab1824018)";
	$dbname="hw2";

    try{
        $conn = new PDO("mysql:host=$dbservername;dbname=$dbname", 
    $dbusername, $dbpassword);
    # set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        $mealname = $_POST['mealname'];
        $quantity = $_POST['quantity'];
        $price = $_POST['price'];
        if(!file_exists($_FILES['photo']["tmp_name"]))
            throw new Exception('未上傳圖片');
        $imgType=$_FILES["photo"]["type"];
        $file = fopen($_FILES['photo']['tmp_name'], "rb") or die("error");
        $fileContents = fread($file, filesize($_FILES['photo']['tmp_name'])); 
        fclose($file);
        $fileContents = base64_encode($fileContents);
        $json = file_get_contents('myfile.json');
        $json_data = json_decode($json,true);
        if(empty($mealname) || empty($quantity) || empty($price))
            throw new Exception('欄位空白');

        if(!ctype_digit($quantity) || !ctype_digit($price))
            throw new Exception('價錢及數量為自然數');

        if(intval($quantity) < 0 || intval($price) < 0)
            throw new Exception('價錢及數量為自然數');

        if(explode($quantity,'0')[0] == null || explode($price,'0')[0] == null)
            throw new Exception('價錢及數量為自然數');

        //Select SID
        $sid = $json_data['SID'];
        $sql = "select * from 店名 where SID =$sid";
        $stmt_4 = $conn->prepare($sql);
        $stmt_4->execute();
        if($stmt_4->rowCount()>0)
        {
            $sql = "INSERT INTO 商品 (商品名稱, 價格, 庫存, 圖片, 圖片型態, SID)
            VALUES ('$mealname', $price, $quantity, '$fileContents', '$imgType', '$sid')";
            $stmt_2 = $conn->prepare($sql);
            $stmt_2->execute();
            $sql = "select * from 店名 NATURAL JOIN 商品 where SID =$sid";
            $stmt_3 = $conn->prepare($sql);
            $stmt_3->execute();
            $row_2 = $stmt_3->fetchALL();  
            if($stmt_3->rowCount()>0)
            {
                $SID = $row_2[0][0];
                $i = 0;
                $array_2 = array();
                while($i<$stmt_3->rowCount())
                {
                    array_push($array_2, array('shopname' => $row_2[$i]['店名'], 'category' => $row_2[$i]['類別'],'price'=>$row_2[$i]['價格'],'product_name'=>$row_2[$i]['商品名稱'], 'number' =>$row_2[$i]['庫存'], 'picture' =>$row_2[$i]['圖片'] ,'picture_type'=>$row_2[$i]['圖片型態'],'latitude'=>$row_2[$i]['緯度'],'longitude'=>$row_2[$i]['經度']));
                    $i = $i+1;
                }
                $json_2 = json_encode($array_2);
                $bytes_2 = file_put_contents("shop.json",$json_2);
                header("Location: https://localhost/HW2_front_end_template/HW2_front_end_template/nav.html");
                exit();
            }
        }
        else
        {
            throw new Exception('請先註冊');
        }
    }
        
    catch(Exception $e)
    {
        $msg=$e->getMessage();
        session_unset(); 
        session_destroy(); 
        echo <<<EOT
        <!DOCTYPE html>
        <html>
        <body>
        <script>
        alert("$msg");
        window.location.replace("nav.html");
        </script>
        </body>
        </html>
    EOT;
    }

?>