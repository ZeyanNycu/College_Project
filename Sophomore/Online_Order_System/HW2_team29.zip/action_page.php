<?php
    session_start();
    $_SESSION['Authenticated']=false;
    
    $dbservername='localhost';
    $dbname='hw2';
    $dbusername='root';
    $dbpassword='Ab1824018)';
    try
    {
        $Json = file_get_contents("myfile.json");
        $myarray = json_decode($Json, true);
        $shop=$_POST['shop'];
        $distance=$_POST['sel1'];
        $a=$_POST['A'];
        $b=$_POST['B'];
        $Meal=$_POST['Meal'];
        $category=$_POST['category'];
        $conn = new PDO("mysql:host=$dbservername;dbname=$dbname", $dbusername, $dbpassword);
        $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $my_loc_long = $myarray['longitude'];
        $my_loc_lat = $myarray['latitude'];
        $sql = "select * from 店名 NATURAL JOIN 商品 where ";
        if(!empty($shop))
        {
            $sql = $sql."店名.店名 like "."'%$shop%' and ";
        }
        if(!empty($distance))
        {
            if($distance == 'near')
            {
                $sql = $sql."ST_Distance_Sphere(店名.位置 ,point('$my_loc_long','$my_loc_lat'))<=10000 and ";
            }
            else if($distance == 'medium')
            {
                $sql = $sql."ST_Distance_Sphere(店名.位置 ,point('$my_loc_long','$my_loc_lat'))>10000 and ST_Distance_Sphere(店名.位置 ,point('$my_loc_long','$my_loc_lat'))<=100000 and ";
            }
            else if($distance == 'far')
            {
                $sql = $sql."ST_Distance_Sphere(店名.位置 ,point('$my_loc_long','$my_loc_lat'))>100000 and ";
            }
        }
        if(!empty($a))
        {
            $sql = $sql."商品.價格 between $a and 999999999 and ";
        }
        if(!empty($b))
        {
            $sql = $sql."商品.價格 between 0 and $b and ";
        }
        if(!empty($Meal))
        {
            $sql = $sql."商品.商品名稱 like "."'%$Meal%' and ";
        }
        if(!empty($category))
        {
            $sql = $sql."店名.類別 like "."'%$category%' and ";
        }
        $sql = $sql.'1';
        $stmt=$conn->prepare($sql);
        $stmt->execute();
        if ($stmt->rowCount()!=0)
        {
            $row = $stmt->fetchALL();
            $i = 0;
            $array = array();
            while($i<$stmt->rowCount())
            {
                array_push($array, array('name' => $row[$i]['店名'], 'category' => $row[$i]['類別'], 'distance' => $distance,'price'=>$row[$i]['價格'],'product_name'=>$row[$i]['商品名稱'], 'number' =>$row[$i]['庫存'], 'picture' =>$row[$i]['圖片'] ,'picture_type'=>$row[$i]['圖片型態']));
                $i = $i+1;
            }
            $json = json_encode($array);
            $bytes = file_put_contents("search_result.json", $json);
            header("Location: https://localhost/HW2_front_end_template/HW2_front_end_template/nav.html");
            exit();
        }
        else
            throw new Exception('搜尋為空');
    }
    catch(Exception $e)
    {
        $msg=$e->getMessage();
        session_unset(); 
        session_destroy(); 
        echo <<<EOT
        <!DOCTYPE html>
        <html>
        <body>
        <script>
        alert("$msg");
        window.location.replace("nav.html");
        </script>
        </body>
        </html>
    EOT;
    }
?>