<?php
session_start();
$_SESSION['Authenticated']=false;

$dbservername='localhost';
$dbname='hw2';
$dbusername='root';
$dbpassword='Ab1824018)';
try{
    if (!isset($_POST['Account']) || !isset($_POST['password']))
    {
        header("Location: index.html");
        exit();
    }
    if (empty($_POST['Account']) || empty($_POST['password']))
        throw new Exception('Please input user name and password.');
    $Account=hash('sha256',$_POST['Account']);
    $password=$_POST['password'];
    $conn = new PDO("mysql:host=$dbservername;dbname=$dbname", 
    $dbusername, $dbpassword);
    # set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    $stmt=$conn->prepare("select * from 使用者 where username=:username");
    $stmt->execute(array('username' => $Account));
    $array = Array();
    $json = json_encode($array);
    $bytes = file_put_contents("search_result.json", $json);
    if ($stmt->rowCount()==1)
    {
        $row = $stmt->fetch();
        $sql = "select * from 店名 NATURAL JOIN 商品 where UID =".$row['UID'];
        $stmt_2 = $conn->prepare($sql);
        $stmt_2->execute();
        $row_2 = $stmt_2->fetchALL();
        $sql = "select * from 店名 where UID =".$row['UID'];
        $stmt_3 = $conn->prepare($sql);
        $stmt_3->execute();
        $row_3 = $stmt_3->fetchALL();
        $array = Array(
            'shopname'=>$row_3[0]['店名'],
            'category'=>$row_3[0]['類別'],
            'latitude'=>$row_3[0]['緯度'],
            'longitude'=>$row_3[0]['經度']
        );
        $json = json_encode($array);
        $bytes = file_put_contents("shop_info.json", $json);
        if ($row['密碼']==hash('sha256',$_POST['password']))
        {
            $_SESSION['Authenticated']=true;
            if($stmt_3->rowCount()>0)
            {
                $SID = $row_3[0]['SID'];
                $i = 0;
                $array_2 = array();
                while($i<$stmt_2->rowCount())
                {
                    array_push($array_2, array('shopname' => $row_2[$i]['店名'], 'category' => $row_2[$i]['類別'],'price'=>$row_2[$i]['價格'],'product_name'=>$row_2[$i]['商品名稱'], 'number' =>$row_2[$i]['庫存'], 'picture' =>$row_2[$i]['圖片'] ,'picture_type'=>$row_2[$i]['圖片型態'],'latitude'=>$row_3[$i]['緯度'],'longitude'=>$row_3[$i]['經度']));
                    $i = $i+1;
                }
                $json_2 = json_encode($array_2);
                $bytes_2 = file_put_contents("shop.json",$json_2);
            } 
            else $SID = '-1';
            $array = Array(
                'UID'=>$row[0],
                'username'=>$_POST['Account'],
                'name'=>$row[3],
                'phonenumber'=>$row[7],
                'latitude'=>$row[6],
                'longitude'=>$row[5],
                'money'=>$row[8],
                'SID'=>$SID,
            );
            $json = json_encode($array);
            $bytes = file_put_contents("myfile.json", $json); 
            header("Location: https://localhost/HW2_front_end_template/HW2_front_end_template/nav.html");
            exit();
        }
        else
            throw new Exception('登入失敗');
    }
    else
        throw new Exception("登入失敗");
}
catch(Exception $e)
{
    $msg=$e->getMessage();
    session_unset(); 
    session_destroy(); 
    echo <<<EOT
    <!DOCTYPE html>
    <html>
    <body>
    <script>
    alert("$msg");
    window.location.replace("https://localhost/HW2_front_end_template/HW2_front_end_template/index.html");
    </script>
    </body>
    </html>
EOT;
}
?>

